import pandas as pd
import warnings
import numpy as np

from learntools.core import *

class GetScore(FunctionProblem):
    _var = 'get_score'
    _test_cases = [
            (10, 22398.78),
    ]
    _hint = ("Begin by making what you did before. Be sure to set the "
             "value for `alpha` in `Ridge()` to the argument supplied to the "
             "`get_score` function. Then, use `cross_val_score()` to get the MAE for each fold, "
             "and take the average. Be sure to set the number of folds to three through the `cv`"
             "parameter.")
    _solution = CS(
"""def get_score(alpha):

    # Step 1: Impute missing values
    imputer = SimpleImputer()
    X_imputed = imputer.fit_transform(X)

    # Step 2: Define the model
    model = Ridge(alpha, random_state=0)

    # Step 3: Evaluate the model using cross-validation
    # Multiply by -1 since sklearn calculates *negative* MAE
    scores = -1 * cross_val_score(model, X_imputed, y, cv=3, scoring='neg_mean_absolute_error')

    return scores.mean().round(2)
""")


class GetDict(CodingProblem):
    _var = 'results'
    _hint = ("Begin by instantiating the dictionary with `results = {}`. Then loop over the value "
             "for `alpha` that will be plugged into the `get_score()` function, and use the "
             "result to set the value in the dictionary.")
    _solution = CS(
"""results = {}
for i in range(1,9):
    results[50*i] = get_score(50*i)
""")



    def check(self, results):

        # columns with missing values
        assert type(results) == dict, \
        "`results` does not appear to be a Python dictionary."

        assert len(results) == 8, \
        "`results` should have 8 entries, one for each tested value of `alpha`."

        assert list(results.keys()) == [50*i for i in range(1,9)], \
        ("The keys in `results` do not appear to be correct.  Please ensure you have one key for each "
         "of 50, 100, 150, ..., 300, 350, 400.")

        assert [round(i) for i in list(results.values())] == [22162, 22002, 21921, 21884, 21872, 21887, 21914, 21950], \
        ("Some of your average MAE scores appear to be incorrect.  Please use the `get_score()` "
         "function from Step 1 to fill in the dictionary values.")

class BestEst(CodingProblem):
    _var = 'alpha_best'
    _hint = ("Find the key corresponding to the minimum value in the `results` dictionary "
             "from the previous step.  This will tell you which value for `alpha_best` "
             "gets the lowest average MAE.")
    _solution = CS("alpha_best = min(results, key=results.get)")

    def check(self, alpha_best):
        assert alpha_best < 18000, \
        ("It looks like you have provided an average MAE value.  Please instead provide a value for "
         "`alpha_best` that indicates the ideal regularization parameter to use in the model. Your answer "
         "should be one of 50, 100, 150, ..., 300, 350, 400.")

        assert alpha_best in [50*i for i in range(1,9)], \
        "Your answer should be one of 50, 100, 150, ..., 300, 350, 400."

        assert alpha_best != 50, \
        ("You should find the value for `alpha_best` with the minimum score, not the maximum score.")

        assert alpha_best == 250, \
        ("Find the key corresponding to the minimum value in the `results` dictionary.")

qvars = bind_exercises(globals(), [
    GetScore,
    GetDict,
    BestEst
    ],
    var_format='step_{n}',
    )
__all__ = list(qvars)
