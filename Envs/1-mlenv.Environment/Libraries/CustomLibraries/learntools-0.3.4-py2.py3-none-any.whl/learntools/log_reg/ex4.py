import sklearn
from sklearn.ensemble import RandomForestClassifier
from learntools.core import *
from sklearn.linear_model import LogisticRegression

class CheckClassifierFit(CodingProblem):

    _vars = ['model', 'X_test', 'y_test']
    _hint = 'Create a LogisticRegrion and fit it to the training data. '
    _solution = CS("""# Define the model. Set random_state to 42
model = LogisticRegression(random_state=1)

# fit your model
model.fit(X_train, y_train)""")

    def check(self, model, X_test, y_test):
        assert isinstance(model, LogisticRegression), "Not using LogisticRegression as the model."
        assert model.random_state == 42, "Didn't set random_state to the right value when initializing the classifier"

class CheckClassifierAccuracy(CodingProblem):

    _vars = ['accuracy']
    _hint = 'Get predictions with model.predict and use metrics.accuracy_score to calculate the accuracy on the validation data'
    _solution = CS("""# Get predictions from the trained model using the testing features
predictions = model.predict(X_test)

# Calculate the accuracy of the trained model with the validation targets and predicted targets
accuracy = metrics.accuracy_score(y_test, predictions)
""")
    def check(self, accuracy):
        assert accuracy < 0.68, "Accuracy is too high, did you use the test data to calculate it?"
        assert accuracy > 0.67, "Accuracy seems too low, did you use the training data for fitting the model?"


class CheckClassifierPrecision(CodingProblem):

    _vars = ['precision']
    _hint = 'Use predictions with model.predict and use metrics.precision_score to calculate the precision on the test data'
    _solution = CS("""
# Calculate the Precision of the trained model with the validation targets and predicted targets
precision = metrics.precision_score(y_test, predictions)
""")
    def check(self, precision):
        assert precision < 0.51, "Precision is too high, did you use the test data to calculate it?"
        assert precision > 0.49, "Precision seems too low, did you use the training data for fitting the model?"



class CheckClassifierRecall(CodingProblem):

    _vars = ['recall']
    _hint = 'Use predictions with model.predict and use metrics.recall_score to calculate the recall on the test data'
    _solution = CS("""
# Calculate the recall of the trained model with the validation targets and predicted targets
recall = metrics.recall_score(y_test, predictions)
""")
    def check(self, recall):
        assert recall < 0.26, "Recall is too high, did you use the test data to calculate it?"
        assert recall > 0.25, "Recall seems too low, did you use the training data for fitting the model?"


class ConfusionMatrixQuestion(ThoughtExperiment):
    _solution = """
    The confusion matrix tells us that we're classifying around 82% of the pulsars correctly. The classifier
    missed 60 pulsars, about 18% of the pulsars in the data, instead classifiying them as noise. However,
    less than 1% of the noise examples were classified as pulsars. Given the small number of pulsars in the dataset,
    our classifier is doing pretty well. With some optimization of the model and data itself, it's likely
    you could improve the true positive rate for the pulsars.
    """

class UnbalancedClassesQuestion(ThoughtExperiment):
    _solution = """
    If your data is 99% noise, then you can easily get 99% accuracy just by classifying everything as noise. If your model
    is actually working, you'd expect to have an accuracy greater than 99%. It's important to look at the confusion matrix
    when you have unbalanced classes like this.
    """

qvars = bind_exercises(globals(), [
    CheckClassifierFit,
    CheckClassifierAccuracy,
    CheckClassifierPrecision,
    CheckClassifierRecall,
    ConfusionMatrixQuestion,
    UnbalancedClassesQuestion
    ],
    var_format='step_{n}',
    )
__all__ = list(qvars)
