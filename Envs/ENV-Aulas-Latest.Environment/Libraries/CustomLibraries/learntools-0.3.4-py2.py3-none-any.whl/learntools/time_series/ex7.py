from learntools.core import *
from learntools.time_series.checking_utils import load_family_sales
from learntools.time_series.utils import make_lags, make_multistep_target
from statsmodels.tsa.arima_model import ARIMA



class Q1(EqualityCheckProblem):  # Match description to dataset
    _vars = ['model', 'p', 'd', 'q']
    _hint = """You should create an Arima model, remember that MA is q, AR is p and I is d."""
    _solution = CS("""
p=1
d=1
q=2
model = ARIMA(df.value, order=(p,d,q))
model_fit = model.fit()
print(model_fit.summary())
""")


    def check(self, model, p, d, q):
        from sklearn.multioutput import RegressorChain
        from statsmodels.tsa.arima_model import ARIMA
        assert isinstance(
            model, ARIMA
        ), f"Your model should be an instance of `ARIMA`. It is actually a `{type(model)}`."
        assert p == 1, (f"Your p value is {p}, it should be 1.")
        assert d == 1, (f"Your d value is {d}, it should be 1.")
        assert q == 2, (f"Your q value is {q}, it should be 2.")



class Q2(ThoughtExperiment):  # Time series features
    _solution = """- The model summary provides lot of information. The table in the middle is the coefficients table where the values under ‘coef’ are the weights of the respective terms.

- The coefficient of the MA2 term is close to zero and the P-Value in ‘P>|z|’ column is highly insignificant. It should ideally be less than 0.05 for the respective X to be significant.

"""


qvars = bind_exercises(globals(), [Q1, Q2], var_format="q_{n}")
__all__ = list(qvars)
