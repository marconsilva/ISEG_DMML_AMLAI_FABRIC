from numpy import array
import pandas as pd
import sklearn
from sklearn.tree import DecisionTreeRegressor
from learntools.core import *
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import confusion_matrix



class SplitData(CodingProblem):
    # test are on train_X and val_y. If these are right, others will be right too.
    _vars = ["X_train", "X_test", "y_train", "y_test", "X", "y"]
    _hint = ("The function you need to import is part of sklearn. When calling "
             "the function, the arguments are X and y. Ensure you set the random_state to 42.")
    _solution = CS("""from sklearn.model_selection import train_test_split

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.33, random_state = 42)""")

    def check(self, X_train, X_test, y_train, y_test, X, y):
        true_X_train, true_X_test, true_y_train, true_y_test = train_test_split(X, y, test_size=0.33, random_state=42)
        
        assert X_train.shape == true_X_train.shape, ("Expected `X_train` to have shape {}. "
                                                     "Your code produced `X_train` with shape {}."
                                                     ).format(true_X_train.shape, X_train.shape)
        assert X_test.shape == true_X_test.shape, ("Expected `X_test` to have shape {}. "
                                                   "Your code produced `X_test` with shape {}."
                                                   ).format(true_X_test.shape, X_test.shape)
        assert y_train.shape == true_y_train.shape, ("Expected `y_train` to have shape {}. "
                                                     "Your code produced `y_train` with shape {}."
                                                     ).format(true_y_train.shape, y_train.shape)
        assert y_test.shape == true_y_test.shape, ("Expected `y_test` to have shape {}. "
                                                   "Your code produced `y_test` with shape {}."
                                                   ).format(true_y_test.shape, y_test.shape)
        # Verify they have set the seed correctly, to help with later steps
        assert all(X_train.index == true_X_train.index), "The training data had different rows than expected"
        assert all(X_test.index == true_X_test.index), "The test data had different rows than expected"
        assert all(y_train.index == true_y_train.index), "The training labels had different rows than expected"
        assert all(y_test.index == true_y_test.index), "The test labels had different rows than expected"




class VerifyDecisionTreeClassifier(CodingProblem):
    _var = 'clf_en'
    _hint = ("Include `random_state`, `criterion`, and `max_depth` when specifying the model. "
             "Data is specified when fitting it.")
    _solution = CS("""from sklearn.tree import DecisionTreeClassifier
clf_en = DecisionTreeClassifier(criterion='entropy', max_depth=3, random_state=0)
clf_en.fit(X_train, y_train)""")

    def check(self, clf_en):
        # Check the type of the model
        assert type(clf_en) == DecisionTreeClassifier, \
            ("Expected `clf_en` to be of type DecisionTreeClassifier but got an "
             "object of type `{}`").format(type(clf_en))
        
        # Check the parameters of the model
        assert clf_en.criterion == 'entropy', "Expected `criterion` to be 'entropy'."
        assert clf_en.max_depth == 3, "Expected `max_depth` to be 3."
        assert clf_en.random_state == 0, "Expected `random_state` to be 0."
        
        # Check if the model has been fitted
        assert getattr(clf_en, 'tree_', None) is not None, "You have not fit the model."


class VerifyConfusionMatrix(CodingProblem):
    _vars = ["cm", "y_test", "y_pred_en"] 
    _hint = ("Use `confusion_matrix` from `sklearn.metrics` to compute the confusion matrix. "
             "Ensure you pass the correct arguments to the function.")
    _solution = CS("""from sklearn.metrics import confusion_matrix
cm = confusion_matrix(y_test, y_pred_en)
print('Confusion matrix\\n\\n', cm)""")

    def check(self, cm, y_test, y_pred_en):
        # Compute the ground truth confusion matrix
        ground_truth_cm = confusion_matrix(y_test, y_pred_en)
        
        # Check if the confusion matrix is correct
        assert cm.shape == ground_truth_cm.shape, ("Your confusion matrix has shape {}. "
                                                   "Expected shape {}").format(cm.shape, ground_truth_cm.shape)
        assert (cm == ground_truth_cm).all(), ("Expected confusion matrix:\n{}\nbut got:\n{}").format(ground_truth_cm, cm)
        
        # Print the confusion matrix for verification
        print('Confusion matrix\n\n', cm)
        
        # For multi-class confusion matrix, we can print each class's TP, FP, FN, TN
        for i in range(cm.shape[0]):
            tp = cm[i, i]
            fp = cm[:, i].sum() - tp
            fn = cm[i, :].sum() - tp
            tn = cm.sum() - (tp + fp + fn)
            print(f"Class {i}: TP={tp}, FP={fp}, FN={fn}, TN={tn}")


qvars = bind_exercises(globals(), [
    SplitData,
    VerifyDecisionTreeClassifier,
    VerifyConfusionMatrix
    ],
    var_format='step_{n}',
    )
__all__ = list(qvars)
