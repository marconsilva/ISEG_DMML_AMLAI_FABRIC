import sklearn
from sklearn.ensemble import RandomForestClassifier
from learntools.core import *
from sklearn.linear_model import LogisticRegression

class CheckClassifierFit(CodingProblem):

    _vars = ['model', 'val_X', 'val_y']
    _hint = 'Create a LogisticRegrion and fit it to the training data. '
    _solution = CS("""# Define the model. Set random_state to 42
model = LogisticRegression(random_state=42)

# fit your model
model.fit(train_X, train_y)""")

    def check(self, model, val_X, val_y):
        assert isinstance(model, LogisticRegression), "Not using LogisticRegression as the model."
        assert model.random_state == 42, "Didn't set random_state to the right value when initializing the classifier"
        assert model.score(val_X, val_y) > 0.67, "Your model isn't quite as accurate as expected."
        assert model.score(val_X, val_y) < 0.69, "Your model isn't quite as accurate as expected."



class CheckClassifierAccuracy(CodingProblem):

    _vars = ['accuracy']
    _hint = 'Get predictions with model.predict and use metrics.accuracy_score to calculate the accuracy on the validation data'
    _solution = CS("""# Get predictions from the trained model using the validation features
pred_y = model.predict(val_X)

# Calculate the accuracy of the trained model with the validation targets and predicted targets
accuracy = metrics.accuracy_score(val_y, pred_y)

""")
    def check(self, accuracy):
        assert accuracy < 0.69, "Accuracy is too high, did you use the validation data to calculate it?"
        assert accuracy > 0.67, "Accuracy seems too low, did you use the training data for fitting the model?"



class CheckClassifierPrecision(CodingProblem):

    _vars = ['precision']
    _hint = 'Use metrics.precision_score to calculate the precision of the model on the validation data'
    _solution = CS("""
precision = metrics.precision_score(val_y, pred_y)
""")

    def check(self, accuracy):
        assert accuracy < 0.51, "Accuracy is too high, did you use the validation data to calculate it?"
        assert accuracy > 0.49, "Accuracy seems too low, did you use the training data for fitting the model?"


class CheckClassifierRecall(CodingProblem):

    _vars = ['recall']
    _hint = 'Use metrics.recall_score to calculate the recall of the model on the validation data'
    _solution = CS("""recall = metrics.recall_score(val_y, pred_y)
                     """)   
    def check(self, recall):
        assert recall < 0.27, "Recall is too high, did you use the validation data to calculate it?"
        assert recall > 0.24, "Recall seems too low, did you use the training data for fitting the model?"



qvars = bind_exercises(globals(), [
    CheckClassifierFit,
    CheckClassifierAccuracy,
    CheckClassifierPrecision,
    CheckClassifierRecall
    ],    
    var_format='step_{n}',
    )
__all__ = list(qvars)
