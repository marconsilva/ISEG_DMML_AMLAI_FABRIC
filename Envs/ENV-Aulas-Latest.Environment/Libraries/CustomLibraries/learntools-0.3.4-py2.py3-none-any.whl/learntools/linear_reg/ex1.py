import pandas as pd
from learntools.core import *
from sklearn.linear_model import LinearRegression

# Load the dataset


df = pd.read_csv("/lakehouse/default/Files/DMML_Aula5/Salary_Data.csv")

class Q1(CodingProblem):
    _hint = "Use the `pd.read_csv` function to read the dataset."
    _solution = "data = pd.read_csv('Salary_Data.csv')"
    _var = "data"

    def check(self, data):
        assert data.equals(df), "The data does not match the expected dataset."

class Q2(CodingProblem):
    _hint = "Use the `LinearRegression` class from `sklearn.linear_model` and the `fit` method."
    _solution = """
from sklearn.linear_model import LinearRegression
model = LinearRegression()
model.fit(X_train,y_train)
"""
    _vars = ["model", "X_train","y_train"]

    def check(self, model,X_train,y_train):
        expected_model = LinearRegression().fit(X_train, y_train)
        assert model.coef_.all() == expected_model.coef_.all() and model.intercept_ == expected_model.intercept_, "The model coefficients or intercept do not match the expected values."

class Q3(CodingProblem):
    _hint = "Use the `predict` method of the fitted model."
    _solution = "predictions = model.predict(X_test)"
    _vars = ["predictions", "X_test","model"]

    def check(self, predictions, X_test, model):
        expected_predictions = model.predict(X_test).reshape(-1, 1)
        predictions = predictions.reshape(-1, 1)

        assert (predictions == expected_predictions).all(), "The predictions do not match the expected values."

        
qvars = bind_exercises(globals(), [Q1, Q2, Q3], var_format="q_{n}")
__all__ = list(qvars)