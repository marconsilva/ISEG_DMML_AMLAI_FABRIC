import sklearn
from sklearn.ensemble import RandomForestClassifier
from learntools.core import *
from sklearn.linear_model import LogisticRegression


class CheckBestParGrid(CodingProblem):

    _vars = ['n_estimators','max_depth']
    _hint = 'Based on what you have learn in tutorial you should create an experiment for Grid Search using the grid provided and then get the best hyper parameters'
    _solution = CS("""regressor = RandomForestRegressor(random_state=0)

hyperparam_grid={'max_depth'   : [ 2,  5,  7, 10],
            'n_estimators': [20, 30, 50, 75]}

gs = GridSearchCV(cv=2, estimator=regressor, param_grid=hyperparam_grid)
gs.fit(X_train, y_train)

print("The best parameters are ",gs.best_params_)
the_best_parameters = gs.best_params_

max_depth = gs.best_params_['max_depth']
n_estimators = gs.best_params_['n_estimators']
""")
    def check(self, n_estimators, max_depth):
        assert n_estimators == 50, "It looks like the n_estimators is not as expected"
        assert max_depth == 7, "It looks like the max_depth is not as expected"


class CheckBestParRand(CodingProblem):

    _vars = ['n_estimators','max_depth']
    _hint = 'Based on what you have learn in tutorial you should create an experiment for Random Search using the grid distribution provided and then get the best hyper parameters'
    _solution = CS("""

regressor = RandomForestRegressor(random_state=0)

hyperparam_grid={'max_depth'   : [ 2,  5,  7, 10],
            'n_estimators': [20, 30, 50, 75]}

gs = RandomizedSearchCV(cv=2, estimator=regressor, param_distributions=hyperparam_grid)
gs.fit(X_train, y_train)

print("The best parameters are ",gs.best_params_)
the_best_parameters = gs.best_params_

max_depth = gs.best_params_['max_depth']
n_estimators = gs.best_params_['n_estimators']
""")
    def check(self, n_estimators, max_depth):
        assert n_estimators == 50, "It looks like the n_estimators is not as expected"
        assert max_depth == 7, "It looks like the max_depth is not as expected"



class CheckClassifierRecall(CodingProblem):

    _vars = ['recall']
    _hint = 'Use predictions with model.predict and use metrics.recall_score to calculate the recall on the test data'
    _solution = CS("""
# Calculate the recall of the trained model with the validation targets and predicted targets
recall = metrics.recall_score(y_test, predictions)
""")
    def check(self, recall):
        assert recall < 0.26, "Recall is too high, did you use the test data to calculate it?"
        assert recall > 0.25, "Recall seems too low, did you use the training data for fitting the model?"


class ConfusionMatrixQuestion(ThoughtExperiment):
    _solution = """
    The confusion matrix tells us that we're classifying around 82% of the pulsars correctly. The classifier
    missed 60 pulsars, about 18% of the pulsars in the data, instead classifiying them as noise. However,
    less than 1% of the noise examples were classified as pulsars. Given the small number of pulsars in the dataset,
    our classifier is doing pretty well. With some optimization of the model and data itself, it's likely
    you could improve the true positive rate for the pulsars.
    """

class UnbalancedClassesQuestion(ThoughtExperiment):
    _solution = """
    If your data is 99% noise, then you can easily get 99% accuracy just by classifying everything as noise. If your model
    is actually working, you'd expect to have an accuracy greater than 99%. It's important to look at the confusion matrix
    when you have unbalanced classes like this.
    """

qvars = bind_exercises(globals(), [
    CheckBestParGrid,
    CheckBestParRand
    ],
    var_format='step_{n}',
    )
__all__ = list(qvars)
