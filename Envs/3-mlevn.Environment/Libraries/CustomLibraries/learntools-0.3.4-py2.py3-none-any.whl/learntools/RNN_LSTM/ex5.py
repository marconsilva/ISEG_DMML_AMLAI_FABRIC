import numpy as np
from learntools.core import *
from keras.models import Sequential
from keras.layers import LSTM, Dense
import numpy as np
#import the meansquared error
from sklearn.metrics import mean_squared_error
import math

#verify this:
class VerifyDataStructure(CodingProblem):
    _vars = ["trainX", "testX"]
    _hint = "Ensure trainX and testX are 3D arrays with the correct shapes."
    _solution = CS("""
trainX = numpy.reshape(trainX, (trainX.shape[0], 1, trainX.shape[1]))
testX = numpy.reshape(testX, (testX.shape[0], 1, testX.shape[1]))
""")
    def check(self, trainX, testX):
        assert isinstance(trainX, np.ndarray), "trainX should be a numpy array."
        assert isinstance(testX, np.ndarray), "testX should be a numpy array."
        assert trainX.ndim == 3, "trainX should be a 3D array."
        assert testX.ndim == 3, "testX should be a 3D array."
        assert trainX.shape[1] == 1, "trainX should have shape (number_of_samples, 1, number_of_features)."
        assert testX.shape[1] == 1, "testX should have shape (number_of_samples, 1, number_of_features)."


""


class CheckifModelisCorrect(CodingProblem):
    _vars = ["model", "trainX", "trainY","time_stemp"]
    _hint = "Ensure your model has the correct layers, input shape, and is compiled and trained correctly."
    _solution = CS("""
                   # Importing the Keras libraries and packages
from keras.models import Sequential
from keras.layers import LSTM, Dense

# Initialising the RNN
model = Sequential()

# Adding the LSTM layer
model.add(LSTM(10, input_shape=(1, time_stemp))) # 10 LSTM neurons (blocks)

# Adding the output layer
model.add(Dense(1))

# Compiling the RNN
model.compile(loss='mean_squared_error', optimizer='adam')


                   """)

    def check(self, model, trainX, trainY, time_stemp):  
        assert isinstance(model, Sequential), "model should be a Keras Sequential model."  
        assert len(model.layers) == 2, "model should have exactly 2 layers."  

        
        # Check the first layer  
        assert isinstance(model.layers[0], LSTM), "The first layer should be an LSTM layer."  
        assert model.layers[0].units == 10, "The LSTM layer should have 10 units."  
  
        # Use model.input_shape to check the input shape  
        input_shape_model = model.input_shape[1:]
        assert input_shape_model == (1, time_stemp), "The model should have input shape (1, time_stemp)."  
  
        # Check the second layer  
        assert isinstance(model.layers[1], Dense), "The second layer should be a Dense layer."  
        assert model.layers[1].units == 1, "The Dense layer should have 1 unit."  
  
        # Check if the model is compiled correctly  
        assert model.loss == 'mean_squared_error', "The model should be compiled with 'mean_squared_error' loss."  
        assert model.optimizer.__class__.__name__ == 'Adam', "The model should be compiled with the 'adam' optimizer."  
  
        # Check the training data  
        assert isinstance(trainX, np.ndarray), "trainX should be a numpy array."  
        assert isinstance(trainY, np.ndarray), "trainY should be a numpy array."  
        

class VerifyRMSECalculation(CodingProblem):
    _vars = ["trainY", "trainPredict", "testY", "testPredict","trainScore","testScore"]
    _hint = "Ensure you are calculating the RMSE correctly using mean_squared_error and math.sqrt."
    _solution = CS("""
                   import math
                   from sklearn.metrics import mean_squared_error

                   trainScore = math.sqrt(mean_squared_error(trainY[0], trainPredict[:,0]))
                   print('Train Score: %.2f RMSE' % (trainScore))
                   testScore = math.sqrt(mean_squared_error(testY[0], testPredict[:,0]))
                   print('Test Score: %.2f RMSE' % (testScore))
                   """)


    def check(self,trainY, trainPredict, testY, testPredict, trainScore, testScore):

        expected_trainScore = math.sqrt(mean_squared_error(trainY[0], trainPredict[:,0]))
        expected_testScore = math.sqrt(mean_squared_error(testY[0], testPredict[:,0]))

        # Compare calculated scores with expected scores
        assert math.isclose(trainScore, expected_trainScore, rel_tol=1e-5), \
            f"Expected trainScore to be {expected_trainScore}, but got {trainScore}"
        assert math.isclose(testScore, expected_testScore, rel_tol=1e-5), \
            f"Expected testScore to be {expected_testScore}, but got {testScore}"


qvars = bind_exercises(globals(), [
        VerifyDataStructure,
        CheckifModelisCorrect,
        VerifyRMSECalculation
    ],
    var_format='step_{n}',
)
__all__ = list(qvars)