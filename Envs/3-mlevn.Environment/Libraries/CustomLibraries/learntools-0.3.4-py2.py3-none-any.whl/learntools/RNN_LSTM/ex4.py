import numpy as np
from learntools.core import *



# Verify Data Structure
class VerifyDataStructure(CodingProblem):
    _vars = ["X_train", "y_train","train_scaled", "timesteps"]
    _hint = "Ensure X_train is a 2D array with shape (number_of_samples, 50) and y_train is a 1D array with the correct number of samples."
    _solution = CS("""
X_train = np.array([train_scaled[i-timesteps:i, 0] for i in range(timesteps, 1258)])
y_train = np.array([train_scaled[i, 0] for i in range(timesteps, 1258)])
""")
    def check(self, X_train, y_train, train_scaled, timesteps):
        #check timestep
        assert timesteps == 50, "timesteps should be 50."
        
        # Check X_train
        assert isinstance(X_train, np.ndarray), "X_train should be a numpy array."
        assert X_train.ndim == 2, "X_train should be a 2D array."
        assert X_train.shape[1] == timesteps, f"Each sample in X_train should have {timesteps} timesteps."
        
        # Check y_train
        assert isinstance(y_train, np.ndarray), "y_train should be a numpy array."
        assert y_train.ndim == 1, "y_train should be a 1D array."
        assert len(y_train) == 1258 - timesteps, "y_train should have the correct number of samples."
        
        # Check alignment
        for i in range(len(X_train)):
            assert np.array_equal(X_train[i], train_scaled[i:i+timesteps, 0]), f"X_train[{i}] does not match the expected sequence"
            assert y_train[i] == train_scaled[i+timesteps, 0], f"y_train[{i}] does not match the expected output value"



class CheckifModelisCorrect(CodingProblem):
    _vars = ["regressor","X_train"]
    _hint = "Make sure you have the correct number of layers and the correct activation functions."
    _solution = CS("""
                   # Importing the Keras libraries and packages
from keras.models import Sequential
from keras.layers import Dense
from keras.layers import SimpleRNN
from keras.layers import Dropout

# Initialising the RNN
regressor = Sequential()

# Adding the first RNN layer and some Dropout regularisation
regressor.add(SimpleRNN(units = 50,activation='tanh', return_sequences = True, input_shape = (X_train.shape[1], 1)))
regressor.add(Dropout(0.2))

# Adding a second RNN layer and some Dropout regularisation
regressor.add(SimpleRNN(units = 50,activation='tanh', return_sequences = True))
regressor.add(Dropout(0.2))

# Adding a third RNN layer and some Dropout regularisation
regressor.add(SimpleRNN(units = 50,activation='tanh', return_sequences = True))
regressor.add(Dropout(0.2))

# Adding a fourth RNN layer and some Dropout regularisation
regressor.add(SimpleRNN(units = 50))
regressor.add(Dropout(0.2))

# Adding the output layer
regressor.add(Dense(units = 1))

# Compiling the RNN
regressor.compile(optimizer = 'adam', loss = 'mean_squared_error')

# Fitting the RNN to the Training set
regressor.fit(X_train, y_train, epochs = 100, batch_size = 32)
""")
    def check(self, regressor, X_train):
        assert (len(regressor.layers) == 9), \
            ("Your model should have nine layers in all. The first four are the RNN layers with Dropout, and the last is the output layer.")
        layer_classes = [layer.__class__.__name__ for layer in regressor.layers]
        true_classes = ['SimpleRNN', 'Dropout', 'SimpleRNN', 'Dropout', 'SimpleRNN', 'Dropout', 'SimpleRNN', 'Dropout', 'Dense']
        # Check layer class
        assert (layer_classes == true_classes), \
            ("Your model doesn't have the correct kinds of layers. You should have layers with classes: SimpleRNN, Dropout, SimpleRNN, Dropout, SimpleRNN, Dropout, SimpleRNN, Dropout, Dense.")
        # Check input shape
        
        input_shape = regressor.input_shape[1:]
        assert (input_shape == (X_train.shape[1], 1)), \
            ("Your model should have input shape ({}, 1). Make sure you answered the previous question correctly!".format(X_train.shape[1]))
        # Check activation functions
        rnn_activations = [layer.activation.__name__ for layer in regressor.layers if hasattr(layer, 'activation')]
        true_activations = ['tanh', 'tanh', 'tanh', 'tanh', 'linear']
        assert (rnn_activations == true_activations), \
            ("Your model doesn't have the correct activations. The `SimpleRNN` layers should have 'tanh' activation, while the output layer should be linear (no activation).")


qvars = bind_exercises(globals(), [
        VerifyDataStructure,
        CheckifModelisCorrect
    ],
    var_format='step_{n}',
)
__all__ = list(qvars)