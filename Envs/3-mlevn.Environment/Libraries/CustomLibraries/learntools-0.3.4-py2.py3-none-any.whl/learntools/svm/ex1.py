from numpy import array
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from learntools.core import *
from sklearn.impute import SimpleImputer
from sklearn.model_selection import train_test_split
# import SVC classifier
from sklearn.svm import SVC
# import metrics to compute accuracy
from sklearn.metrics import accuracy_score

class SplitData(CodingProblem):
    # test are on X_train and y_test. If these are right, others will be right too.
    _vars = ["X_train", "X_test", "y_train", "y_test", "X", "y"]
    _hint = ("The function you need to import is part of sklearn. When calling "
         "the function, the arguments are X and y. Ensure you set the random_state to 42. "
         "The output variables should be named X_train, X_test, y_train, and y_test.")
    _solution = CS("""from sklearn.model_selection import train_test_split
from sklearn.impute import SimpleImputer

X = df.drop(['target_class'], axis=1)
y = df['target_class']

# Impute missing values
imputer = SimpleImputer(strategy='mean')
X_imputed = imputer.fit_transform(X)

# Split the dataset
X_train, X_test, y_train, y_test = train_test_split(X_imputed, y, test_size=0.2, random_state=42)""")


    def check(self, X_train, X_test, y_train, y_test, X, y):
        from sklearn.impute import SimpleImputer
        from sklearn.model_selection import train_test_split
        import numpy as np

        # Impute missing values
        imputer = SimpleImputer(strategy='mean')
        X_imputed = imputer.fit_transform(X)

        # Split the dataset
        true_X_train, _, _, true_y_test = train_test_split(X_imputed, y, test_size=0.2, random_state=42)
        
        assert X_train.shape == true_X_train.shape, ("Expected `X_train` to have shape {}. "
                                                     "Your code produced `X_train` with shape {}."
                                                     ).format(true_X_train.shape, X_train.shape)
        assert y_test.shape == true_y_test.shape, ("Expected `y_test` to have shape {}. "
                                                     "Your code produced `y_test` with shape {}."
                                                     ).format(true_y_test.shape, y_test.shape)
        # Verify they have set the seed correctly, to help with later steps
        assert np.array_equal(X_train, true_X_train), "The training data had different rows than expected"


class FitModelWithTrain(CodingProblem):
    _vars = ['svc', 'X_train', 'y_train']
    _hint = 'Remember to fit the classifier with the training data.'
    _solution = CS("""from sklearn.svm import SVC

# instantiate classifier with default hyperparameters
svc = SVC()

# fit classifier to training set
svc.fit(X_train, y_train)""")

    def check(self, svc, X_train, y_train):
        from sklearn.svm import SVC
        from sklearn.metrics import accuracy_score

        assert hasattr(svc, "fit"), "The model should be an instance of SVC."
        assert svc.__class__.__name__ == "SVC", "Ensure you are using the SVC classifier."
        
        # Fitting this model is cheap. So we do it in check
        correct_model = SVC()
        correct_model.fit(X_train, y_train)
        
        # Check if the model is fitted
        assert hasattr(svc, "support_"), "You have not fit your model yet."
        
        # Check if the model produces the same predictions
        expected_pred = correct_model.predict(X_train[:10])
        actual_pred = svc.predict(X_train[:10])
        assert all(actual_pred == expected_pred), (
            "Model was tested by predicting the value of the first 10 rows of training data. "
            "Expected prediction of `{}`. Model actually predicted `{}`. "
            "Did you pass the right data?").format(expected_pred, actual_pred)
        

class FitModelWithTrain2(CodingProblem):
    _vars = ['svc', 'X_train', 'y_train']
    _hint = 'Remember to fit the classifier with the training data.'
    _solution = CS("""from sklearn.svm import SVC

# instantiate classifier with rbf kernel and C=100
svc = SVC(C=100.0)

# fit classifier to training set
svc.fit(X_train, y_train)""")

    def check(self, svc, X_train, y_train):
        from sklearn.svm import SVC
        from sklearn.metrics import accuracy_score

        assert hasattr(svc, "fit"), "The model should be an instance of SVC."
        assert svc.__class__.__name__ == "SVC", "Ensure you are using the SVC classifier."
        assert svc.C == 100.0, "Ensure you are setting the parameter C to 100.0."
        
        # Fitting this model is cheap. So we do it in check
        correct_model = SVC(C=100.0)
        correct_model.fit(X_train, y_train)
        
        # Check if the model is fitted
        assert hasattr(svc, "support_"), "You have not fit your model yet."
        
        # Check if the model produces the same predictions
        expected_pred = correct_model.predict(X_train[:10])
        actual_pred = svc.predict(X_train[:10])
        assert all(actual_pred == expected_pred), (
            "Model was tested by predicting the value of the first 10 rows of training data. "
            "Expected prediction of `{}`. Model actually predicted `{}`. "
            "Did you pass the right data?").format(expected_pred, actual_pred)
        


class Though1(ThoughtExperiment):
    _solution = """
    We get maximum accuracy with polynomial kernel with C=100.0. and the accuracy is 0.9816. Based on the above analysis we can conclude that our classification model accuracy is very good. Our model is doing a very good job in terms of predicting the class labels.

    But, this is not true. Here, we have an imbalanced dataset. The problem is that accuracy is an inadequate measure for quantifying predictive performance in the imbalanced dataset problem.

    So, we must explore alternative metrics that provide better guidance in selecting models. In particular, we would like to know the underlying distribution of values and the type of errors our classifier is making.

    One such metric to analyze the model performance in imbalanced classes problem is `Confusion matrix`.
    """


class CheckGridSearchCV(CodingProblem):
    _vars = ['grid_search', 'svc', 'parameters', 'X_train', 'y_train']
    _hint = 'Make sure to set up GridSearchCV with the correct parameters and fit it to the training data.'
    _solution = CS("""
grid_search = GridSearchCV(estimator = svc,  
                           param_grid = parameters,
                           scoring = 'accuracy',
                           cv = 5,
                           verbose=0)


grid_search.fit(X_train, y_train)
""")

    def check(self, grid_search, svc, parameters, X_train, y_train):
        from sklearn.model_selection import GridSearchCV
        from sklearn.svm import SVC

        assert isinstance(grid_search, GridSearchCV), "grid_search should be an instance of GridSearchCV."
        assert grid_search.estimator.__class__.__name__ == "SVC", "The estimator should be an instance of SVC."
        assert grid_search.param_grid == parameters, "The param_grid is not set correctly."
        assert grid_search.scoring == 'accuracy', "The scoring parameter should be set to 'accuracy'."
        assert grid_search.cv == 5, "The cv parameter should be set to 5."
        assert grid_search.verbose == 0, "The verbose parameter should be set to 0."

      



class Though2(ThoughtExperiment):
    _solution = """
    

    1. There are outliers in our dataset. So, as we increase the value of C to limit fewer outliers, the accuracy increased. This is true with different kinds of kernels.

    2.	We get maximum accuracy with `rbf` and `linear` kernel with C=100.0 and the accuracy is 0.9777. So, we can conclude that our model is doing a very good job in terms of predicting the class labels. But, this is not true. Here, we have an imbalanced dataset. Accuracy is an inadequate measure for quantifying predictive performance in the imbalanced dataset problem. So, we must explore `confusion matrix` that provide better guidance in selecting models. 

    3.	we obtain higher average stratified k-fold cross-validation score of 0.9789 with linear kernel but the model accuracy is 0.9832. So, stratified cross-validation technique does not help to improve the model performance.

    4.	Our original model test accuracy is 0.9777 while GridSearch CV score on test-set is 0.9812. So, GridSearch CV helps to identify the parameters that will improve the performance for this particular model.
    """


qvars = bind_exercises(globals(), [
    SplitData,
    FitModelWithTrain,
    FitModelWithTrain2,
    Though1,
    CheckGridSearchCV,
    Though2
    ],
    var_format='step_{n}',
    )
__all__ = list(qvars)
