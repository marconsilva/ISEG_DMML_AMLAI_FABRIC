import sklearn
from sklearn.ensemble import RandomForestRegressor
from learntools.core import *
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error
import numpy as np


class CheckCorrelatedFeature(ThoughtExperiment):
    _solution = \
"""
Based off this plot, the most correlated feature with Yearly Amount Spent is Length of Membership.
"""

    def check(self, response):
        assert response == "Length of Membership", f"Expected 'Length of Membership', but got {response}."

class CheckRegressorFit(CodingProblem):

    _vars = ['model', 'X_test', 'y_test']
    _hint = 'Create a LinearRegression and fit it to the training data.'
    _solution = CS("""# Define the model
model = LinearRegression()

# fit your model
model.fit(X_train, y_train)""")

    def check(self, model, X_test, y_test):
        assert isinstance(model, LinearRegression), "Not using LinearRegression as the model."
        assert model.score(X_test, y_test) > 0.98, "Your model isn't quite as accurate as expected."
        assert model.score(X_test, y_test) < 0.99, "Your model isn't quite as accurate as expected."


class CheckRegressorMetrics(CodingProblem):

    _vars = ['mae', 'mse', 'rmse']
    _hint = 'Get predictions with model.predict and use mean_absolute_error, mean_squared_error to calculate the metrics on the validation data'
    _solution = CS("""
# Calculate the MAE, MSE, and RMSE of the trained model with the validation targets and predicted targets
from sklearn import metrics
mae = metrics.mean_absolute_error(y_test, predictions)
mse = metrics.mean_squared_error(y_test, predictions)
rmse= np.sqrt(metrics.mean_squared_error(y_test, predictions))
""")

    def check(self, mae, mse, rmse):
        assert np.isclose(mae, 7.228, atol=0.001), f"MAE is not as expected. Got {mae}"
        assert np.isclose(mse, 79.813, atol=0.001), f"MSE is not as expected. Got {mse}"
        assert np.isclose(rmse, 8.934, atol=0.001), f"RMSE is not as expected. Got {rmse}"


class CheckCoef(ThoughtExperiment):
    _solution = \
"""
Interpreting the coefficients:

- Holding all other features fixed, a 1 unit increase in **Avg. Session Length** is associated with an **increase of 25.98 total dollars spent**.
- Holding all other features fixed, a 1 unit increase in **Time on App** is associated with an **increase of 38.59 total dollars spent**.
- Holding all other features fixed, a 1 unit increase in **Time on Website** is associated with an **increase of 0.19 total dollars spent**.
- Holding all other features fixed, a 1 unit increase in **Length of Membership** is associated with an **increase of 61.27 total dollars spent**.
"""




class LastAna(ThoughtExperiment):
    _solution = \
"""
This is tricky, there are two ways to think about this: Develop the Website to catch up to the performance of the mobile app, or develop the app more since that is what is working better. 
This sort of answer really depends on the other factors going on at the company, you would probably want to explore the relationship between Length of Membership and the App or the Website before coming to a conclusion!
"""



qvars = bind_exercises(globals(), [
    CheckCorrelatedFeature,
    CheckRegressorFit,
    CheckRegressorMetrics,
    CheckCoef,
    LastAna
    ],    
    var_format='step_{n}',
    )
__all__ = list(qvars)