import sklearn
from sklearn.ensemble import RandomForestClassifier
from learntools.core import *
from sklearn.linear_model import LogisticRegression
from numpy import array
import pandas as pd
import sklearn
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeRegressor
from learntools.core import *



class SplitData(CodingProblem):
    # test are on train_X and val_y. If these are right, others will be right too.
    _vars = ["train_X", "val_X", "train_y", "val_y", "X", "y"]
    _hint = ("The function you need to import is part of sklearn. When calling "
             "the function, the arguments are X and y. Ensure you set the random_state to 42.")
    _solution = CS("""from sklearn.model_selection import train_test_split

X = ad_data[['Daily Time Spent on Site', 'Age', 'Area Income','Daily Internet Usage', 'Male']]
y = ad_data['Clicked on Ad']
train_X, val_X, train_y, val_y = train_test_split(X, y, test_size=0.33, random_state=42)""")

    def check(self, train_X, val_X, train_y, val_y, X, y):

        true_train_X, _, _, true_val_y =  train_test_split(X, y,test_size=0.33, random_state=42)
        assert train_X.shape == true_train_X.shape, ("Expected `train_X` to have shape {}. "
                                                     "Your code produced `train_X` with shape {}."
                                                     ).format(true_train_X.shape, train_X.shape)
        assert val_y.shape == true_val_y.shape, ("Expected `val_y` to have shape {}. "
                                                     "Your code produced `val_y` with shape {}."
                                                     ).format(true_val_y.shape, val_y.shape)
        # Verify they have set the seed correctly, to help with later steps
        assert all(train_X.index == true_train_X.index), "The training data had different rows than expected"


class FitModelWithTrain(CodingProblem):
    _vars = ['model', 'train_X', 'train_y', 'val_X']
    _hint = 'Remember, you fit with training data. You will test with validation data soon'
    _solution = CS("""from sklearn.linear_model import LogisticRegression

model = LogisticRegression(random_state=42)
model.fit(train_X,train_y)""")

    def check(self, model, train_X, train_y, val_X):
        #check if it is logist regression
        assert isinstance(model, LogisticRegression), "Not using LogisticRegression as the model."
        assert model.random_state == 42, "Ensure you created your model with `random_state=1`"
        # Fitting this model is cheap. So we do it in check
        correct_model = LogisticRegression(random_state=1)
        correct_model.fit(train_X, train_y)
        expected_pred = correct_model.predict(val_X.head(10))
        actual_pred = model.predict(val_X.head(10))
        print(expected_pred)
        print(actual_pred)
        assert all(actual_pred == expected_pred), (
                    "Model was tested by predicting the value of first row training data. "
                    "Expected prediction of `{}`. Model actually predicted `{}`. "
                    "Did you set the `random_state` and pass the right data?").format(expected_pred, actual_pred)

class ValPreds(CodingProblem):
    _vars = ['val_predictions', 'model', 'val_X']
    _hint = 'Run predict on the right validation data object.'
    _solution = CS("""val_predictions = model.predict(val_X)""")

    def check(self, val_predictions, model, val_X):
        comparison_val_preds = model.predict(val_X)
        assert all(comparison_val_preds == val_predictions), ("Predictions do not match expectations. "
                                                             "Did you supply the right data? The dataset `val_X` contains the validation observations.")





qvars = bind_exercises(globals(), [
    SplitData,
    FitModelWithTrain,
    ValPreds
    ],
    var_format='step_{n}',
    )
__all__ = list(qvars)
